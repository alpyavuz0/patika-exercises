<h2><blockquote> This is Simple Light Weight Offline Documentation for Font-Awesome 5.8.2 </blockquote></h2>

## How to use:
Clone the Repository, Open ``index.html `` Simple ``:)``

Reason Why I've Made this. Many Times I work offline, and on Slow Internet, Searching Icon on FontAwesome.com takes time hence I made this Fast Search Method.

I Hope They Will understand and Add Somthing like this in their official website :). Using this, Development Seems to be Quicker and Easier  `:)`

### More Versions incoming.

Live URL: https://imlolman.github.io/Font-Awesome-Offline-Quick-Icon-Search/
